export enum ApiType {
  Summarize = 'Summarize',
  Translate = 'Translate',
  Write = 'Write',
  Rewrite = 'Rewrite',
  Proofread = 'Proofread',
  Prompt = 'Prompt',
  Innovate = 'Innovate',
  Visualize = 'Visualize',
  Journey = 'Journey',
  Twin = 'Twin',
  Perspective = 'Perspective',
}

export type Tone = 'Default' | 'Formal' | 'Casual' | 'Persuasive' | 'Enthusiastic';

export type InnovationFormat = 'Research Paper' | 'Invention' | 'Theory';

export type CognitiveState = 'Confused' | 'Curious' | 'Confident' | 'Neutral';

export interface CognitiveStateAnalysis {
  cognitiveState: CognitiveState;
  unarticulatedNeed: {
    label: string;
    action: {
      newInput: string;
    };
  };
}

export interface StructuredInnovationOutput {
  format: InnovationFormat;
  title: string;
  [key: string]: any; // Allows for flexible properties based on format
}

export interface PerspectiveOutput {
  beginner: string;
  expert: string;
  alien: string;
  futureSelf: string;
}

export interface CognitiveProfile {
  profileTitle: string;
  summary: string;
  traits: {
    name: string;
    description: string;
  }[];
}

export interface SuggestedAction {
  label: string;
  api: ApiType;
}

export interface PreCognitiveAction {
  label: string;
  newInput?: string;
  api?: ApiType;
}

export interface FutureInsightAction {
  premonition: string;
  solutionLabel: string;
  solutionAction: {
    newInput?: string;
    api?: ApiType;
  };
}

export interface HistoryItem {
  id: string;
  parentId: string | null;
  api: ApiType;
  input: string;
  output: string;
  timestamp: Date;
  image: { data: string; mimeType: string } | null;
  tone?: Tone;
  language?: string;
  innovationFormat?: InnovationFormat;
}

export interface VisualizationData {
  nodes: { id: string; label: string }[];
  links: { source: string; target: string; label: string }[];
}