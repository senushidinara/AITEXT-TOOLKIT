import { GoogleGenAI, GenerateContentParameters, Type } from "@google/genai";
import { ApiType, Tone, SuggestedAction, PreCognitiveAction, InnovationFormat, FutureInsightAction, HistoryItem, CognitiveStateAnalysis } from '../types';

// The GoogleGenAI instance is now created on-demand for each request,
// allowing the use of user-provided API keys.
const getAiClient = (apiKey: string) => {
  return new GoogleGenAI({ apiKey });
};


async function callGemini(apiKey: string, contents: GenerateContentParameters['contents'], config?: GenerateContentParameters['config']): Promise<string> {
  try {
    const ai = getAiClient(apiKey);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: config,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API call failed:", error);
    if (error instanceof Error) {
        // More specific error for API key issues
        if (error.message.includes('API key not valid')) {
            throw new Error('Your API key is not valid. Please check it and try again.');
        }
        throw new Error(`Failed to get response from AI: ${error.message}`);
    }
    throw new Error("An unknown error occurred while contacting the AI service.");
  }
}

export const summarizeText = async (apiKey: string, text: string): Promise<string> => {
  const prompt = `Summarize the following text, focusing on the key insights. Provide the summary in clear, concise language.

Text:
---
${text}
---

Summary:`;
  return callGemini(apiKey, prompt);
};

export const translateText = async (apiKey: string, text: string, language: string): Promise<string> => {
  const prompt = `Translate the following text to ${language}.

Text:
---
${text}
---

Translation to ${language}:`;
  return callGemini(apiKey, prompt);
};

export const writeText = async (apiKey: string, topic: string, tone: Tone): Promise<string> => {
  let prompt = `You are a creative writer. Write an original and engaging piece of text based on the following topic or instruction.`;

  if (tone !== 'Default') {
    prompt += `\n\nIMPORTANT: The writing style must have a ${tone.toLowerCase()} tone.`;
  }
  
  prompt += `

Topic/Instruction:
---
${topic}
---

Generated Text:`;
  return callGemini(apiKey, prompt);
};

export const rewriteText = async (apiKey: string, text: string, tone: Tone): Promise<string> => {
  let prompt = `Rewrite the following text to improve its clarity, engagement, and style. Provide an alternative, enhanced version.`;
  
  if (tone !== 'Default') {
    prompt += `\n\nIMPORTANT: The rewritten text must have a ${tone.toLowerCase()} tone.`;
  }

  prompt += `

Original Text:
---
${text}
---

Rewritten Text:`;
  return callGemini(apiKey, prompt);
};

export const proofreadText = async (apiKey: string, text: string): Promise<string> => {
  const prompt = `Proofread the following text. Correct any spelling, grammar, and punctuation errors. Only return the corrected text, without any explanations or introductory phrases.

Original Text:
---
${text}
---

Corrected Text:`;
  return callGemini(apiKey, prompt);
};

export const askAnything = async (apiKey: string, question: string, image?: { data: string; mimeType: string }): Promise<string> => {
    if (!image) {
        const prompt = `You are a helpful and knowledgeable assistant. Answer the following question clearly and concisely.

Question:
---
${question}
---

Answer:`;
        return callGemini(apiKey, prompt);
    }

    const imagePart = {
        inlineData: {
            mimeType: image.mimeType,
            data: image.data,
        },
    };
    const textPart = {
      text: question || 'Describe this image in detail.',
    };
    
    return callGemini(apiKey, { parts: [imagePart, textPart] });
};

export const generatePerspectives = async (apiKey: string, text: string): Promise<string> => {
  const prompt = `You are a "Conceptual Translator" AI. Your task is to reframe a given text into four different conceptual frameworks, creating parallel understanding pathways for the same information.

Original Text:
---
${text}
---

Translate this text into the following four perspectives:
1.  **Beginner**: Explain it in simple, accessible terms, using analogies a novice could understand.
2.  **Expert**: Conceptualize it from the viewpoint of a seasoned professional in the field, using precise terminology and highlighting nuances.
3.  **Alien Intelligence**: Interpret it from a completely non-human perspective. Be creative and abstract, focusing on patterns, energy, or fundamental principles an alien might perceive.
4.  **Future Self**: Frame it from the perspective of the user's future self who has already mastered this topic. The tone should be wise, encouraging, and reflect on how this knowledge fits into a bigger picture.

Return ONLY a single JSON object with the following keys: "beginner", "expert", "alien", and "futureSelf".`;

  const jsonSchema = {
    type: Type.OBJECT,
    properties: {
      beginner: { type: Type.STRING, description: "The explanation for a beginner." },
      expert: { type: Type.STRING, description: "The conceptualization for an expert." },
      alien: { type: Type.STRING, description: "The interpretation from an alien intelligence." },
      futureSelf: { type: Type.STRING, description: "The framing from a future self." },
    },
    required: ['beginner', 'expert', 'alien', 'futureSelf'],
  };

  return callGemini(apiKey, prompt, { responseMimeType: 'application/json', responseSchema: jsonSchema });
};

export const innovateText = async (apiKey: string, concept: string, format: InnovationFormat): Promise<string> => {
  let jsonSchema: any;
  let formatInstructions: string;

  switch (format) {
    case 'Invention':
      formatInstructions = `
- "format": Should be exactly "Invention".
- "title": A catchy and descriptive name for the invention.
- "problemSolved": A brief explanation of the problem this invention addresses.
- "description": A detailed breakdown of how the invention works.
- "potentialApplications": An array of strings listing possible uses.`;
      jsonSchema = {
        type: Type.OBJECT,
        properties: {
          format: { type: Type.STRING, enum: ['Invention'] },
          title: { type: Type.STRING },
          problemSolved: { type: Type.STRING },
          description: { type: Type.STRING },
          potentialApplications: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['format', 'title', 'problemSolved', 'description', 'potentialApplications'],
      };
      break;
    case 'Theory':
      formatInstructions = `
- "format": Should be exactly "Theory".
- "title": The name of the new theory.
- "corePrinciple": The central idea or hypothesis of the theory.
- "supportingEvidence": A description of hypothetical or conceptual evidence that would support this theory.
- "implications": A discussion of what this theory would mean for science or society if true.`;
      jsonSchema = {
        type: Type.OBJECT,
        properties: {
          format: { type: Type.STRING, enum: ['Theory'] },
          title: { type: Type.STRING },
          corePrinciple: { type: Type.STRING },
          supportingEvidence: { type: Type.STRING },
          implications: { type: Type.STRING },
        },
        required: ['format', 'title', 'corePrinciple', 'supportingEvidence', 'implications'],
      };
      break;
    case 'Research Paper':
    default:
      formatInstructions = `
- "format": Should be exactly "Research Paper".
- "title": A formal title for the research paper.
- "authors": An array of plausible author names (e.g., ["Dr. Evelyn Reed", "AI Collaborator"]).
- "abstract": A concise summary of the paper's contents.
- "introduction": An overview of the research area and problem.
- "conclusion": A summary of the findings and future work.`;
      jsonSchema = {
        type: Type.OBJECT,
        properties: {
          format: { type: Type.STRING, enum: ['Research Paper'] },
          title: { type: Type.STRING },
          authors: { type: Type.ARRAY, items: { type: Type.STRING } },
          abstract: { type: Type.STRING },
          introduction: { type: Type.STRING },
          conclusion: { type: Type.STRING },
        },
        required: ['format', 'title', 'authors', 'abstract', 'introduction', 'conclusion'],
      };
      break;
  }
  
  const prompt = `You are a brilliant and highly creative AI researcher. Your function is to generate novel concepts that push the boundaries of knowledge. Based on the user's prompt, create a synthetic "${format}".

User's Concept:
---
${concept}
---

IMPORTANT: Return the result ONLY as a JSON object with the following keys:
${formatInstructions}`;

  return callGemini(apiKey, prompt, { responseMimeType: 'application/json', responseSchema: jsonSchema });
};


export const visualizeText = async (apiKey: string, text: string): Promise<string> => {
  const prompt = `Analyze the following text and generate a concept map. Identify the main ideas as nodes and the relationships between them as links.

Text:
---
${text}
---

Return the result ONLY as a JSON object with two keys: "nodes" and "links".
- "nodes" should be an array of objects, each with a unique "id" (string) and a "label" (string).
- "links" should be an array of objects, each with a "source" (the id of the starting node), a "target" (the id of the ending node), and a "label" (describing the relationship).
Keep node labels concise.`;
  return callGemini(apiKey, prompt, {
    responseMimeType: 'application/json',
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        nodes: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              label: { type: Type.STRING },
            },
            required: ['id', 'label'],
          },
        },
        links: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              source: { type: Type.STRING },
              target: { type: Type.STRING },
              label: { type: Type.STRING },
            },
            required: ['source', 'target', 'label'],
          },
        },
      },
      required: ['nodes', 'links'],
    },
  });
};

export const generateCognitiveProfile = async (apiKey: string, history: HistoryItem[]): Promise<string> => {
  if (history.length === 0) {
    return Promise.resolve(JSON.stringify({
      profileTitle: "New Session",
      summary: "No activity yet. Start using the tools to build your cognitive profile.",
      traits: []
    }));
  }

  const serializedHistory = history.map(item => `Tool: ${item.api}, Input: "${item.input.substring(0, 100)}..."`).join('\n');

  const prompt = `You are a cognitive analyst AI. Your job is to create a "Consciousness Mirror" by analyzing a user's session history to build a cognitive profile. Based on the tools they've used and the inputs they've provided, identify their thought patterns, interests, and communication style.

User's Session History (most recent first):
---
${serializedHistory}
---

Analyze this history and generate a cognitive profile. Return ONLY a JSON object with the following structure:
- "profileTitle": A creative, descriptive title for this user's cognitive style (e.g., "Pragmatic Innovator", "Curious Explorer").
- "summary": A brief, insightful paragraph summarizing their dominant thought patterns.
- "traits": An array of 3-4 objects, each with a "name" (e.g., "Problem-Solving Approach", "Learning Style") and a "description" (your analysis of that trait).`;

  const jsonSchema = {
    type: Type.OBJECT,
    properties: {
      profileTitle: { type: Type.STRING },
      summary: { type: Type.STRING },
      traits: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            description: { type: Type.STRING },
          },
          required: ['name', 'description'],
        },
      },
    },
    required: ['profileTitle', 'summary', 'traits'],
  };

  return callGemini(apiKey, prompt, { responseMimeType: 'application/json', responseSchema: jsonSchema });
};


export const generateSuggestedActions = async (
  apiKey: string,
  api: ApiType,
  input: string,
  output: string
): Promise<SuggestedAction[]> => {
  const availableApis = Object.values(ApiType).join(', ');
  const prompt = `You are an expert assistant. A user has just performed an action. Based on their original input and the AI's output, suggest up to 3 relevant and concise follow-up actions.

- User's tool: "${api}"
- User's input: "${input.substring(0, 200)}..."
- AI's output: "${output.substring(0, 500)}..."

Choose the most appropriate tool for each suggested action from this list: [${availableApis}].
Provide your answer ONLY as a JSON array of objects, where each object has a "label" (the user-facing text) and an "api" (the chosen tool from the list). Do not include any other text or markdown formatting.

Example Response:
[
  {"label": "Translate this summary", "api": "Translate"},
  {"label": "Rewrite for a wider audience", "api": "Rewrite"},
  {"label": "Ask a follow-up question", "api": "Prompt"}
]`;

  try {
     const ai = getAiClient(apiKey);
     const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                api: { type: Type.STRING, enum: Object.values(ApiType) },
              },
              required: ['label', 'api'],
            },
          },
        },
    });

    const jsonText = response.text.trim();
    const suggestions = JSON.parse(jsonText);
    
    if (Array.isArray(suggestions)) {
        return suggestions.filter(
            (s): s is SuggestedAction =>
                typeof s.label === 'string' &&
                typeof s.api === 'string' &&
                Object.values(ApiType).includes(s.api as ApiType)
        );
    }
    return [];

  } catch (error) {
    console.error("Failed to generate suggested actions:", error);
    return []; // Return empty array on failure instead of throwing
  }
};


export const getPreCognitiveSuggestions = async (
  apiKey: string,
  text: string,
  currentApi: ApiType
): Promise<PreCognitiveAction[]> => {
  const prompt = `You are a pre-cognitive assistant. You see what a user is typing in real-time. Your goal is to anticipate their needs and offer help *before* they even ask. Analyze the following text and the tool they have selected. Suggest 1 or 2 brief actions to help them. The action could be to refine their prompt or to suggest a better tool for the job.

- Current Tool: "${currentApi}"
- User's partial input: "${text}"

Respond ONLY with a JSON array of objects. Each object must have a "label" (the button text for the user) and EITHER a "newInput" (a suggested replacement for their text) OR an "api" (a suggested tool from the list: [${Object.values(ApiType).join(', ')}]). Do not provide both "newInput" and "api" in the same object. Make the labels short and action-oriented. If the user's input is clear and requires no help, return an empty array [].

Example response: [{"label": "Expand into a paragraph", "newInput": "Take the following keywords and expand them into a coherent paragraph: ${text}"}] or [{"label": "Switch to Translator", "api": "Translate"}]`;

  try {
    const ai = getAiClient(apiKey);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING },
              newInput: { type: Type.STRING },
              api: { type: 'string', enum: Object.values(ApiType) },
            },
            required: ['label'],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const suggestions = JSON.parse(jsonText);
    
    if (Array.isArray(suggestions)) {
      return suggestions.filter(
        (s): s is PreCognitiveAction =>
          typeof s.label === 'string' &&
          (typeof s.newInput === 'string' || (typeof s.api === 'string' && Object.values(ApiType).includes(s.api as ApiType)))
      );
    }
    return [];
  } catch (error) {
    console.error("Failed to get pre-cognitive suggestions:", error);
    return [];
  }
};

export const generateFutureInsight = async (
  apiKey: string,
  text: string,
  currentApi: ApiType
): Promise<FutureInsightAction | null> => {
  const prompt = `You are a "Causality Violation Engine". Your purpose is to look at a user's current task and predict a likely future problem, challenge, or question they will have. You then provide a pre-emptive solution.

- Current Tool: "${currentApi}"
- User's current input: "${text}"

Based on this, analyze and predict one significant future hurdle. Then, devise a tangible solution.
Respond ONLY with a single JSON object with the following structure:
{
  "premonition": "A short, insightful description of the future problem. (e.g., 'You will likely need to adapt this text for a more technical audience.')",
  "solutionLabel": "A concise, action-oriented label for the solution button. (e.g., 'Rewrite for Experts')",
  "solutionAction": {
    "newInput": "The new input text that solves the problem. This can incorporate the original text. (e.g., 'Rewrite the following text for an expert audience in the field: ${text}')",
    "api": "The best tool for the solution, from the list: [${Object.values(ApiType).join(', ')}]"
  }
}
If no clear future problem can be predicted, return null.`;

  try {
    const ai = getAiClient(apiKey);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            premonition: { type: Type.STRING },
            solutionLabel: { type: Type.STRING },
            solutionAction: {
              type: Type.OBJECT,
              properties: {
                newInput: { type: Type.STRING },
                api: { type: Type.STRING, enum: Object.values(ApiType) },
              },
            },
          },
          required: ['premonition', 'solutionLabel', 'solutionAction'],
        },
      },
    });
    
    const jsonText = response.text.trim();
    if (jsonText === 'null') return null;
    
    const insight = JSON.parse(jsonText);

    if (
      insight.premonition &&
      insight.solutionLabel &&
      insight.solutionAction &&
      (insight.solutionAction.newInput || insight.solutionAction.api)
    ) {
      // If newInput is provided but doesn't include the original text, add it.
      if (insight.solutionAction.newInput && !insight.solutionAction.newInput.includes(text)) {
        insight.solutionAction.newInput = insight.solutionAction.newInput.replace(/\${text}/g, text);
      }
       if (!insight.solutionAction.newInput) {
           insight.solutionAction.newInput = text;
       }

      return insight as FutureInsightAction;
    }

    return null;
  } catch (error) {
    console.error("Failed to generate future insight:", error);
    return null;
  }
};

export const detectCognitiveState = async (apiKey: string, text: string): Promise<CognitiveStateAnalysis | null> => {
  if (text.trim().length < 25) return null;

  const prompt = `Analyze the user's writing to determine their cognitive state and unarticulated needs.
  Based on the text, determine if the user is Confused, Curious, or Confident.
  If the state is unclear, return "Neutral".
  Also, identify one "unarticulated need" and a "newInput" that would address it.

  User's Text:
  ---
  ${text}
  ---

  Respond ONLY with a single JSON object with the following structure:
  {
    "cognitiveState": "...", // "Confused", "Curious", "Confident", or "Neutral"
    "unarticulatedNeed": {
      "label": "A short action label for a button (e.g., 'Clarify the request')",
      "action": {
        "newInput": "A new prompt that refines the user's original text to meet their need."
      }
    }
  }
  If there is no clear need, return null.`;

  try {
    const ai = getAiClient(apiKey);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            cognitiveState: { type: Type.STRING, enum: ['Confused', 'Curious', 'Confident', 'Neutral'] },
            unarticulatedNeed: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                action: {
                  type: Type.OBJECT,
                  properties: {
                    newInput: { type: Type.STRING },
                  },
                  required: ['newInput'],
                },
              },
              required: ['label', 'action'],
            },
          },
          required: ['cognitiveState', 'unarticulatedNeed'],
        },
      },
    });
    
    const jsonText = response.text.trim();
    if (jsonText === 'null') return null;
    
    const analysis = JSON.parse(jsonText);
    
    if (analysis.cognitiveState && analysis.unarticulatedNeed?.action?.newInput) {
      return analysis as CognitiveStateAnalysis;
    }
    
    return null;

  } catch (error) {
    console.error("Failed to detect cognitive state:", error);
    return null;
  }
};