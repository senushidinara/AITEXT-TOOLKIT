import { ApiType, Tone } from './types';
import SummarizeIcon from './components/icons/SummarizeIcon';
import TranslateIcon from './components/icons/TranslateIcon';
import WriteIcon from './components/icons/WriteIcon';
import RewriteIcon from './components/icons/RewriteIcon';
import ProofreadIcon from './components/icons/ProofreadIcon';
import PromptIcon from './components/icons/PromptIcon';
import InnovateIcon from './components/icons/InnovateIcon';
import VisualizeIcon from './components/icons/VisualizeIcon';
import JourneyIcon from './components/icons/JourneyIcon';
import TwinIcon from './components/icons/TwinIcon';
import PerspectiveIcon from './components/icons/PerspectiveIcon';

export const ApiDetails = {
  [ApiType.Summarize]: {
    label: 'Summarizer',
    Icon: SummarizeIcon,
    description: 'Distill complex information into clear insights.',
    inputLabel: 'Text to Summarize',
    actionText: 'Summarize Text',
    placeholder: 'Paste a long article, report, or document here...',
    examples: [
        'A news article about renewable energy.',
        'The transcript of a podcast episode.',
        'A scientific paper on climate change.',
        'Meeting notes from a project kickoff.',
        'A chapter from a history book.',
    ],
  },
  [ApiType.Translate]: {
    label: 'Translator',
    Icon: TranslateIcon,
    description: 'Translate text into your preferred language.',
    inputLabel: 'Text to Translate',
    actionText: 'Translate Text',
    placeholder: 'Enter text in any language...',
    examples: [
        '"Hello, how are you?"',
        '"¿Dónde está la biblioteca?"',
        'A paragraph from a French novel.',
        'Lyrics to a song in Japanese.',
        'A recipe written in Italian.',
    ],
  },
  [ApiType.Write]: {
    label: 'Writer',
    Icon: WriteIcon,
    description: 'Create original and engaging text from a prompt.',
    inputLabel: 'Topic / Prompt',
    actionText: 'Write Text',
    placeholder: 'Give the AI a topic or instruction...',
    examples: [
        'Write a short blog post about the benefits of remote work.',
        'An email to my team about the new project deadline.',
        'A short story set in a futuristic city.',
        'Brainstorm a list of names for a new tech startup.',
        'Create an ad copy for a new brand of coffee.',
    ],
  },
  [ApiType.Rewrite]: {
    label: 'Rewriter',
    Icon: RewriteIcon,
    description: 'Improve content with alternative options.',
    inputLabel: 'Text to Rewrite',
    actionText: 'Rewrite Text',
    placeholder: 'Paste the text you want to improve or rephrase here...',
    examples: [
        'An email that sounds too blunt.',
        'A sentence that feels clumsy or too long.',
        'A paragraph from an essay to make it more academic.',
        'Marketing text to make it more persuasive.',
        'A social media post to make it more engaging.',
    ],
  },
  [ApiType.Proofread]: {
    label: 'Proofreader',
    Icon: ProofreadIcon,
    description: 'Correct spelling, grammar, and punctuation.',
    inputLabel: 'Text to Proofread',
    actionText: 'Proofread Text',
    placeholder: 'Paste text here to check for any errors...',
    examples: [
        'Your final resume draft.',
        'An important email before you send it.',
        'A blog post you\'ve just written.',
        'An academic paper\'s abstract.',
        'Any text where spelling and grammar are critical.',
    ],
  },
  [ApiType.Prompt]: {
    label: 'Prompt',
    Icon: PromptIcon,
    description: 'A flexible, multimodal tool. Ask questions, analyze images, or give creative instructions.',
    inputLabel: 'Your Prompt',
    actionText: 'Submit Prompt',
    placeholder: 'Ask a question, analyze an image, or give a creative instruction...',
    examples: [
        'Explain the theory of relativity like I\'m five.',
        'What are the main themes in the book \'Dune\'?',
        'Help me plan a 3-day trip to Tokyo.',
        'Write a simple Python script to scrape a website.',
        'If you upload an image: "Write a poem about this image."',
    ],
  },
  [ApiType.Innovate]: {
    label: 'Innovator',
    Icon: InnovateIcon,
    description: 'Generate new theories, ideas, and synthetic knowledge.',
    inputLabel: 'Concept to Innovate',
    actionText: 'Invent Solution',
    placeholder: 'Describe a problem or a concept to generate a novel solution...',
    examples: [
        'A method for biodegradable plastics using mushroom mycelium.',
        'A new theory of consciousness based on quantum entanglement.',
        'A sustainable method for desalinating ocean water.',
        'An invention that allows humans to communicate with plants.',
        'A business model for a zero-waste grocery store.',
    ],
  },
  [ApiType.Visualize]: {
    label: 'Visualizer',
    Icon: VisualizeIcon,
    description: 'Create a visual map of concepts and their connections.',
    inputLabel: 'Text to Visualize',
    actionText: 'Visualize Concepts',
    placeholder: 'Paste text here to see how its ideas connect, diverge, and evolve...',
    examples: [
        'The plot summary of a complex movie.',
        'An article explaining a political ideology.',
        'A company\'s organizational chart described in text.',
        'The steps involved in a scientific process.',
        'A philosophical argument with premises and conclusions.',
    ],
  },
   [ApiType.Perspective]: {
    label: 'Perspective',
    Icon: PerspectiveIcon,
    description: 'Reframe text through different conceptual lenses to unlock deeper understanding.',
    inputLabel: 'Text to Reframe',
    actionText: 'Generate Perspectives',
    placeholder: 'Enter a concept or idea to see it from multiple viewpoints...',
    examples: [
        'The concept of "entropy".',
        'The historical significance of the printing press.',
        'A line of code from a complex algorithm.',
        'The lyrics to a philosophical song.',
        'A legal clause from a contract.',
    ],
  },
  [ApiType.Journey]: {
    label: 'Journey',
    Icon: JourneyIcon,
    description: 'Visualize your session as a thought journey. See how ideas connect and evolve, and travel back to any point in time.',
    inputLabel: '', // Not applicable
    actionText: '', // Not applicable
    placeholder: '', // Not applicable
    examples: [],
  },
  [ApiType.Twin]: {
    label: 'Cognitive Twin',
    Icon: TwinIcon,
    description: 'The AI analyzes your session activity to generate a cognitive profile, mirroring your thought patterns and interests.',
    inputLabel: 'Cognitive Profile',
    actionText: 'Analyze Session',
    placeholder: '', // Not applicable
    examples: [],
  }
};

export const LANGUAGES = [
  'Spanish', 'French', 'German', 'Italian', 'Portuguese', 'Dutch', 
  'Russian', 'Chinese (Simplified)', 'Japanese', 'Korean', 'Arabic', 'Hindi'
];

export const TONES: Tone[] = ['Default', 'Formal', 'Casual', 'Persuasive', 'Enthusiastic'];