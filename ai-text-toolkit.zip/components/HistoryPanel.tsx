import React from 'react';
import { HistoryItem } from '../types';
import { ApiDetails } from '../constants';
import XMarkIcon from './icons/XMarkIcon';

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onItemClick: (item: HistoryItem) => void;
  onClear: () => void;
}

const groupHistoryByDate = (historyItems: HistoryItem[]) => {
    const groups: { [key: string]: HistoryItem[] } = {
        'Today': [],
        'Yesterday': [],
        'Previous 7 Days': [],
        'Older': []
    };

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    historyItems.forEach(item => {
        const itemDate = item.timestamp;
        if (itemDate >= today) {
            groups['Today'].push(item);
        } else if (itemDate >= yesterday) {
            groups['Yesterday'].push(item);
        } else if (itemDate >= sevenDaysAgo) {
            groups['Previous 7 Days'].push(item);
        } else {
            groups['Older'].push(item);
        }
    });

    return groups;
};

const HistoryPanel: React.FC<HistoryPanelProps> = ({ isOpen, onClose, history, onItemClick, onClear }) => {
    if (!isOpen) return null;

    const formatTimestamp = (date: Date) => {
        return new Intl.DateTimeFormat('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        }).format(date);
    }

    const childrenMap = new Map<string, HistoryItem[]>();
    const rootItems: HistoryItem[] = [];

    history.forEach(item => {
        if (item.parentId && history.some(h => h.id === item.parentId)) {
            if (!childrenMap.has(item.parentId)) {
                childrenMap.set(item.parentId, []);
            }
            childrenMap.get(item.parentId)!.push(item);
        } else {
            rootItems.push(item);
        }
    });

    childrenMap.forEach(children => children.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime()));
    rootItems.sort((a,b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    const groupedRootItems = groupHistoryByDate(rootItems);

    const renderHistoryNode = (item: HistoryItem) => {
        const details = ApiDetails[item.api];
        const itemChildren = childrenMap.get(item.id) || [];

        return (
            <li key={item.id} className="relative">
                <button 
                    onClick={() => onItemClick(item)}
                    className="w-full text-left p-3 my-1 rounded-lg hover:bg-gray-700/50 transition-colors"
                >
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                            <details.Icon className="h-5 w-5 text-indigo-400 shrink-0" />
                            <span className="font-semibold text-gray-300">{details.label}</span>
                        </div>
                        <span className="text-xs text-gray-500">{formatTimestamp(item.timestamp)}</span>
                    </div>
                    <p className="text-sm text-gray-400 truncate">
                        {item.input || 'Image Prompt'}
                    </p>
                </button>
                {itemChildren.length > 0 && (
                    <ul className="pl-5 relative before:content-[''] before:absolute before:left-2 before:top-0 before:bottom-0 before:w-0.5 before:bg-gray-600">
                        {itemChildren.map(child => renderHistoryNode(child))}
                    </ul>
                )}
            </li>
        );
    };

  return (
    <div 
        className="fixed inset-0 bg-black/60 z-30 transition-opacity animate-fade-in" 
        onClick={onClose}
    >
      <div 
        className="absolute left-0 top-0 h-full w-full max-w-md bg-gray-800 border-r border-gray-700 shadow-2xl flex flex-col transition-transform transform"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between p-4 border-b border-gray-700 shrink-0">
          <h2 className="text-xl font-bold text-gray-200">History</h2>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
                 <button 
                    onClick={onClear}
                    className="px-3 py-1 text-sm bg-red-800/50 text-red-300 rounded-md hover:bg-red-700/50"
                 >
                    Clear All
                 </button>
            )}
            <button onClick={onClose} className="p-1 text-gray-400 rounded-full hover:bg-gray-700">
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>
        </header>
        <div className="flex-grow overflow-y-auto p-2">
            {history.length === 0 ? (
                <div className="flex items-center justify-center h-full text-gray-500">
                    <p>Your session history will appear here.</p>
                </div>
            ) : (
                <div>
                    {Object.entries(groupedRootItems).map(([groupTitle, items]) =>
                        items.length > 0 ? (
                            <div key={groupTitle} className="mb-4">
                                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                                    {groupTitle}
                                </h3>
                                <ul>{items.map(item => renderHistoryNode(item))}</ul>
                            </div>
                        ) : null
                    )}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default HistoryPanel;