import React from 'react';
import { FutureInsightAction } from '../types';
import FutureIcon from './icons/FutureIcon';

interface FutureInsightProps {
  insight: FutureInsightAction | null;
  isForecasting: boolean;
  onActionClick: (action: FutureInsightAction['solutionAction']) => void;
}

const FutureInsight: React.FC<FutureInsightProps> = ({ insight, isForecasting, onActionClick }) => {
  if (!isForecasting && !insight) {
    return null;
  }

  return (
    <div className="mt-6 animate-fade-in">
        <div className="bg-gray-800/50 backdrop-blur-sm border border-purple-500/30 rounded-xl shadow-lg shadow-purple-900/20 p-4">
            <h3 className="flex items-center text-lg font-semibold text-gray-200 mb-3">
                <FutureIcon className="h-6 w-6 mr-3 text-purple-400" />
                Future Insight
            </h3>
            {isForecasting && (
                <p className="text-sm text-gray-400 italic">Forecasting potential futures...</p>
            )}
            {insight && (
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                        <p className="font-semibold text-purple-300">Premonition:</p>
                        <p className="text-gray-300">{insight.premonition}</p>
                    </div>
                    <button
                        onClick={() => onActionClick(insight.solutionAction)}
                        className="flex-shrink-0 px-4 py-2 bg-purple-600 text-white font-bold rounded-lg shadow-md hover:bg-purple-700 transition-all duration-200 transform hover:scale-105"
                    >
                        {insight.solutionLabel}
                    </button>
                </div>
            )}
        </div>
    </div>
  );
};

export default FutureInsight;
