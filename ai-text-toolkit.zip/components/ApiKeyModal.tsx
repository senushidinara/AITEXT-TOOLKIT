import React, { useState } from 'react';
import KeyIcon from './icons/KeyIcon';
import XMarkIcon from './icons/XMarkIcon';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (key: string) => void;
  hasKey: boolean;
}

const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, onSave, hasKey }) => {
  const [apiKey, setApiKey] = useState('');

  if (!isOpen) {
    return null;
  }

  const handleSave = () => {
    if (apiKey.trim()) {
      onSave(apiKey.trim());
      setApiKey(''); // Clear field after saving
    } else {
      onClose(); // Close if field is empty and a key already exists
    }
  };
  
  const handleBackdropClick = () => {
    // Only allow closing via backdrop if a key is already set
    if (hasKey) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center animate-fade-in" onClick={handleBackdropClick}>
      <div
        className="bg-gray-800 border border-gray-700 rounded-xl shadow-2xl w-full max-w-md flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <KeyIcon className="h-6 w-6 text-indigo-400" />
            <h2 className="text-xl font-bold text-gray-200">Manage API Key</h2>
          </div>
          {hasKey && (
             <button onClick={onClose} className="p-1 text-gray-400 rounded-full hover:bg-gray-700">
                <XMarkIcon className="h-6 w-6" />
             </button>
          )}
        </header>
        <div className="p-6">
          <p className="text-gray-400 mb-4">
            To use this application, you need a Google AI API key. Your key is stored securely in your browser's local storage and is never sent to our servers.
          </p>
          <p className="text-sm text-gray-500 mb-4">
            You can get your own free key from <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">Google AI Studio</a>.
          </p>
          <div className="mb-4">
            <label htmlFor="api-key-input" className="block text-sm font-medium text-gray-300 mb-2">
              Your Google AI API Key
            </label>
            <input
              id="api-key-input"
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={hasKey ? "Enter new key to update" : "Enter your API key here"}
              className="w-full bg-gray-900 border border-gray-600 text-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>
        </div>
        <footer className="p-4 bg-gray-800/50 border-t border-gray-700 rounded-b-xl flex justify-end">
          <button
            onClick={handleSave}
            className="px-6 py-2 bg-indigo-600 text-white font-bold rounded-lg shadow-md hover:bg-indigo-700 transition-colors"
          >
            Save and Close
          </button>
        </footer>
      </div>
    </div>
  );
};

export default ApiKeyModal;
