import React from 'react';

const FutureSelfIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12c0-1.232-.046-2.453-.138-3.662a4.006 4.006 0 0 0-3.7-3.7 48.678 48.678 0 0 0-7.324 0 4.006 4.006 0 0 0-3.7 3.7c-.092 1.21-.138 2.43-.138 3.662m15 0c0 3.857-3.44 6.996-7.5 6.996S4.5 15.857 4.5 12m15 0a48.667 48.667 0 0 0-7.5 0C8.44 12 4.5 8.996 4.5 5.004S8.44 1.008 12 1.008s7.5 3.996 7.5 7.996" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12v3.75m0-11.25v2.25m-3.75 3h7.5" />
  </svg>
);

export default FutureSelfIcon;