import React from 'react';

const AlienIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75c1.148 0 2.25.233 3.25.65v-3.85a.75.75 0 0 0-.42-1.325l-2.618-.873a.75.75 0 0 1-.42-1.325l2.618-.873a.75.75 0 0 0 .42-1.325v-1.125a3.75 3.75 0 0 0-7.5 0v1.125a.75.75 0 0 0 .42 1.325l2.618.873a.75.75 0 0 1 .42 1.325l-2.618.873a.75.75 0 0 0-.42 1.325v3.85c1-.417 2.102-.65 3.25-.65Z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5c0 4.142 3.358 7.5 7.5 7.5s7.5-3.358 7.5-7.5" />
    </svg>
);

export default AlienIcon;