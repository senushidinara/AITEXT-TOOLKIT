import React from 'react';

const VisualizeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 1 0 7.5 7.5h-7.5V6Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5H21A7.5 7.5 0 0 0 13.5 3v7.5Z" />
    <circle cx="12" cy="12" r="2.5" fill="currentColor" />
    <circle cx="6" cy="7" r="2" fill="currentColor" />
    <circle cx="17" cy="7" r="2" fill="currentColor" />
    <circle cx="18" cy="17" r="2" fill="currentColor" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 14.5s-1-2-4-3.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 14.5s1-2 5-2.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 8.5s2 1.5 4 1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="m16 8.5-3 1.5" />
  </svg>
);

export default VisualizeIcon;
