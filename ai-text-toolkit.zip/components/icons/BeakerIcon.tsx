import React from 'react';

const BeakerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 6.087c0-.66.537-1.197 1.197-1.197h.006c.66 0 1.197.537 1.197 1.197v7.506c0 .66-.537 1.197-1.197 1.197h-.006c-.66 0-1.197-.537-1.197-1.197V6.087ZM6 18h6c.66 0 1.197-.537 1.197-1.197V6.087c0-.66-.537-1.197-1.197-1.197H6.006c-.66 0-1.197.537-1.197 1.197v10.716c0 .66.537 1.197 1.197 1.197Z" />
  </svg>
);

export default BeakerIcon;
