import React from 'react';

const FutureIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 11.667 0l3.181-3.183m-4.991-2.696v4.992h-4.992v-4.992zM9.345 16.023l-3.181-3.182a8.25 8.25 0 0 1 11.667 0l3.181 3.182m0-11.667-3.181 3.182a8.25 8.25 0 0 0-11.667 0L2.985 4.356Z" />
  </svg>
);

export default FutureIcon;
