import React from 'react';

const PerspectiveIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" opacity="0.4" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.75h16.5" opacity="0.4" />
    <rect x="5" y="5" width="14" height="14" rx="1" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

export default PerspectiveIcon;