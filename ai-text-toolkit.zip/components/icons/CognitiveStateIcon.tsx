import React from 'react';
import { CognitiveState } from '../types';
import QuestionMarkCircleIcon from './QuestionMarkCircleIcon';
import SparklesIcon from './SparklesIcon';
import ExclamationTriangleIcon from './ExclamationTriangleIcon';
import MinusCircleIcon from './MinusCircleIcon';

interface CognitiveStateIconProps extends React.SVGProps<SVGSVGElement> {
  state: CognitiveState;
}

const CognitiveStateIcon: React.FC<CognitiveStateIconProps> = ({ state, ...props }) => {
  switch (state) {
    case 'Curious':
      return <QuestionMarkCircleIcon {...props} />;
    case 'Confident':
      return <SparklesIcon {...props} />;
    case 'Confused':
      return <ExclamationTriangleIcon {...props} />;
    case 'Neutral':
      return <MinusCircleIcon {...props} />;
    default:
      return null;
  }
};

export default CognitiveStateIcon;