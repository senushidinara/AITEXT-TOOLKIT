import React from 'react';

const JourneyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <circle cx="6" cy="6" r="2.5" fill="currentColor" opacity="0.5"/>
        <circle cx="6" cy="18" r="2.5" fill="currentColor" opacity="0.5"/>
        <circle cx="18" cy="12" r="2.5" fill="currentColor" opacity="0.5"/>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 8.5V15.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.5 6H12c2.21 0 4 1.79 4 4s-1.79 4-4 4h-1.5" />
    </svg>
);

export default JourneyIcon;
