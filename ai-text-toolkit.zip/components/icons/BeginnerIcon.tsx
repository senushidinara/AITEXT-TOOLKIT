import React from 'react';

const BeginnerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.636 5.636a9 9 0 1 0 12.728 0M12 3v9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12a3 3 0 0 1 3 3H9a3 3 0 0 1 3-3Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v5.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 20.25h7.5" />
  </svg>
);

export default BeginnerIcon;