import React from 'react';
import ChevronRightIcon from './icons/ChevronRightIcon';

interface ExamplePromptsProps {
  prompts: string[];
  onPromptClick: (prompt: string) => void;
}

const ExamplePrompts: React.FC<ExamplePromptsProps> = ({ prompts, onPromptClick }) => {
  return (
    <div className="p-4 pt-0 animate-fade-in">
      <h4 className="text-sm font-semibold text-gray-400 mb-2">Or try an example:</h4>
      <div className="space-y-2">
        {prompts.map((prompt, index) => (
          <button
            key={index}
            onClick={() => onPromptClick(prompt)}
            className="w-full text-left flex items-center p-2 rounded-md bg-gray-700/50 hover:bg-gray-700 transition-colors"
          >
            <ChevronRightIcon className="h-4 w-4 mr-2 text-indigo-400 shrink-0" />
            <span className="text-sm text-gray-300">{prompt}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ExamplePrompts;
