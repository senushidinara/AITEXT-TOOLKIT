import React, { useState, useEffect, useRef, useMemo } from 'react';
import { HistoryItem } from '../types';
import { ApiDetails } from '../constants';

interface JourneyDisplayProps {
  history: HistoryItem[];
  onNodeClick: (item: HistoryItem) => void;
}

interface Node {
  id: string;
  item: HistoryItem;
}

interface Link {
  source: string;
  target: string;
}

interface Position {
  x: number;
  y: number;
}

interface Velocity {
  vx: number;
  vy: number;
}

// Fix: The force layout simulation logic has been corrected.
// The original implementation had a bug with stale closures in the animation loop,
// causing the graph to jiggle randomly instead of settling.
// This version uses the functional update form of `useState` to ensure the simulation
// correctly calculates node positions based on the previous state in each frame.
const useForceLayout = (nodes: Node[], links: Link[], width: number, height: number) => {
  // Fix: Use lazy initialization for useState to resolve potential compiler issues.
  // Fix: Explicitly providing generic type arguments to the `new Map()` constructor to resolve the compiler error.
  const [positions, setPositions] = useState<Map<string, Position>>(() => new Map<string, Position>());
  // Fix: The error "Expected 1 arguments, but got 0" likely refers to this line, where the generic type arguments were missing from the Map constructor.
  // Fix: Explicitly provide generic type arguments to the `new Map()` constructor to resolve the compiler error "Expected 1 arguments, but got 0."
  const velocitiesRef = useRef<Map<string, Velocity>>(new Map<string, Velocity>());
  // Fix: The error "Expected 1 arguments, but got 0" indicates `useRef()` requires an initial value. Initialize with `null`.
  const simulationRef = useRef<number | null>(null);

  useEffect(() => {
    // Initialize positions and velocities
    const newPositions = new Map<string, Position>();
    const newVelocities = new Map<string, Velocity>();
    nodes.forEach(node => {
        newPositions.set(node.id, { x: Math.random() * width, y: Math.random() * height });
        newVelocities.set(node.id, { vx: 0, vy: 0 });
    });
    setPositions(newPositions);
    velocitiesRef.current = newVelocities;

    const simulation = () => {
        setPositions(prevPositions => {
            if (prevPositions.size === 0 && nodes.length > 0) {
                // Initial positions might not be set yet, wait for next frame.
                return prevPositions;
            }

            const currentPositions = new Map(prevPositions);
            const currentVelocities = velocitiesRef.current;
            
            const REPULSION_STRENGTH = 2000;
            const LINK_STRENGTH = 0.1;
            const LINK_DISTANCE = 150;
            const CENTER_STRENGTH = 0.05;
            const DAMPING = 0.9;

            nodes.forEach(node1 => {
                let totalForceX = 0;
                let totalForceY = 0;

                const pos1 = currentPositions.get(node1.id);
                if (!pos1) return;

                // Repulsion from other nodes
                nodes.forEach(node2 => {
                    if (node1.id === node2.id) return;
                    const pos2 = currentPositions.get(node2.id);
                    if (!pos2) return;

                    const dx = pos1.x - pos2.x;
                    const dy = pos1.y - pos2.y;
                    const distance = Math.sqrt(dx * dx + dy * dy) || 1;
                    const force = REPULSION_STRENGTH / (distance * distance);
                    totalForceX += (dx / distance) * force;
                    totalForceY += (dy / distance) * force;
                });

                // Attraction to center
                const dxCenter = width / 2 - pos1.x;
                const dyCenter = height / 2 - pos1.y;
                totalForceX += dxCenter * CENTER_STRENGTH;
                totalForceY += dyCenter * CENTER_STRENGTH;

                const vel = currentVelocities.get(node1.id);
                if (vel) {
                    vel.vx = (vel.vx + totalForceX) * DAMPING;
                    vel.vy = (vel.vy + totalForceY) * DAMPING;
                }
            });

            // Link forces
            links.forEach(link => {
                const sourcePos = currentPositions.get(link.source);
                const targetPos = currentPositions.get(link.target);
                if (!sourcePos || !targetPos) return;

                const dx = targetPos.x - sourcePos.x;
                const dy = targetPos.y - sourcePos.y;
                const distance = Math.sqrt(dx * dx + dy * dy) || 1;
                
                const force = (distance - LINK_DISTANCE) * LINK_STRENGTH;
                const fx = (dx / distance) * force;
                const fy = (dy / distance) * force;

                const sourceVel = currentVelocities.get(link.source);
                const targetVel = currentVelocities.get(link.target);
                if (sourceVel && targetVel) {
                    sourceVel.vx += fx;
                    sourceVel.vy += fy;
                    targetVel.vx -= fx;
                    targetVel.vy -= fy;
                }
            });
            
            nodes.forEach(node => {
                const pos = currentPositions.get(node.id);
                const vel = currentVelocities.get(node.id);
                if (pos && vel) {
                    pos.x += vel.vx;
                    pos.y += vel.vy;

                    // Boundary checks
                    pos.x = Math.max(20, Math.min(width - 20, pos.x));
                    pos.y = Math.max(20, Math.min(height - 20, pos.y));
                }
            });

            return new Map(currentPositions);
        });
        simulationRef.current = requestAnimationFrame(simulation);
    };

    simulationRef.current = requestAnimationFrame(simulation);

    return () => {
        if (simulationRef.current) {
            cancelAnimationFrame(simulationRef.current);
        }
    };
  }, [nodes, links, width, height]);

  return positions;
};

const JourneyDisplay: React.FC<JourneyDisplayProps> = ({ history, onNodeClick }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

    const { nodes, links } = useMemo(() => {
        const nodes: Node[] = history.map(item => ({ id: item.id, item }));
        const links: Link[] = history
            .filter(item => item.parentId && history.some(h => h.id === item.parentId))
            .map(item => ({ source: item.parentId!, target: item.id }));
        return { nodes: nodes.reverse(), links };
    }, [history]);
    
    useEffect(() => {
        const updateDimensions = () => {
            if (containerRef.current) {
                setDimensions({
                    width: containerRef.current.clientWidth,
                    height: containerRef.current.clientHeight
                });
            }
        };
        updateDimensions();
        const resizeObserver = new ResizeObserver(updateDimensions);
        if(containerRef.current) {
            resizeObserver.observe(containerRef.current);
        }
        return () => resizeObserver.disconnect();
    }, []);

    const positions = useForceLayout(nodes, links, dimensions.width, dimensions.height);

    if (history.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 p-8">
                 <h2 className="text-2xl font-bold text-gray-200 mb-4">Your Thought Journey</h2>
                <p>Your session history is currently empty.</p>
                <p className="mt-2 text-sm">Use any tool, and your journey will be visualized here.</p>
            </div>
        );
    }
    
    return (
        <div className="p-4 md:p-6 lg:p-8 flex flex-col h-full overflow-hidden">
            <h2 className="text-2xl font-bold text-gray-200 shrink-0">Your Thought Journey</h2>
            <p className="text-gray-400 mb-6 shrink-0">
                This is a map of your interactions. Click a node to travel back to that point.
            </p>
            <div ref={containerRef} className="flex-grow w-full h-full bg-gray-800/50 rounded-lg border border-gray-700 relative overflow-hidden">
                <svg width={dimensions.width} height={dimensions.height} className="absolute inset-0">
                     <defs>
                        <marker id="arrow" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                            <path d="M 0 0 L 10 5 L 0 10 z" fill="#6b7280" />
                        </marker>
                    </defs>
                    {links.map(link => {
                        const sourcePos = positions.get(link.source);
                        const targetPos = positions.get(link.target);
                        if (!sourcePos || !targetPos) return null;
                        return (
                            <line
                                key={`${link.source}-${link.target}`}
                                x1={sourcePos.x} y1={sourcePos.y}
                                x2={targetPos.x} y2={targetPos.y}
                                stroke="#6b7280" strokeWidth="1.5"
                                markerEnd="url(#arrow)"
                            />
                        );
                    })}
                    {nodes.map(node => {
                        const pos = positions.get(node.id);
                        if (!pos) return null;
                        const details = ApiDetails[node.item.api];
                        const Icon = details.Icon;
                        return (
                            <g 
                                key={node.id} 
                                transform={`translate(${pos.x}, ${pos.y})`}
                                onClick={() => onNodeClick(node.item)}
                                className="cursor-pointer group"
                            >
                                <circle r="22" fill="#1f2937" stroke="#4f46e5" strokeWidth="2" className="group-hover:stroke-purple-400 transition-colors"/>
                                <foreignObject x="-12" y="-12" width="24" height="24">
                                    <Icon className="text-indigo-400 group-hover:text-purple-300 transition-colors" />
                                </foreignObject>
                                 <text y="38" textAnchor="middle" fill="#d1d5db" fontSize="12" className="font-sans opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    {details.label}
                                </text>
                            </g>
                        );
                    })}
                </svg>
            </div>
        </div>
    );
};

export default JourneyDisplay;