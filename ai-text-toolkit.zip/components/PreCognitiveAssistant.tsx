import React from 'react';
import { PreCognitiveAction } from '../types';
import BrainCircuitIcon from './icons/BrainCircuitIcon';

interface PreCognitiveAssistantProps {
  actions: PreCognitiveAction[];
  onActionClick: (action: PreCognitiveAction) => void;
  isThinking: boolean;
}

const PreCognitiveAssistant: React.FC<PreCognitiveAssistantProps> = ({ actions, onActionClick, isThinking }) => {
  const hasContent = isThinking || actions.length > 0;

  if (!hasContent) {
    return null;
  }

  return (
    <div className="bg-gray-900/80 backdrop-blur-md border border-gray-700 rounded-lg p-2.5 shadow-lg animate-fade-in">
         <div className="flex items-center gap-3">
            <BrainCircuitIcon className="h-5 w-5 text-indigo-400 shrink-0" />
            {isThinking && <span className="text-sm text-gray-400 italic">Thinking...</span>}
            {!isThinking && actions.length > 0 && (
                <div className="flex flex-wrap gap-2">
                    {actions.map((action, index) => (
                    <button
                        key={index}
                        onClick={() => onActionClick(action)}
                        className="px-2.5 py-1 bg-gray-700 text-gray-300 rounded-md text-xs font-medium hover:bg-indigo-600 hover:text-white transition-colors"
                    >
                        {action.label}
                    </button>
                    ))}
                </div>
            )}
         </div>
    </div>
  );
};

export default PreCognitiveAssistant;