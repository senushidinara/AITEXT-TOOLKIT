import React from 'react';
import { ApiType } from '../types';
import { ApiDetails } from '../constants';
import ChevronDoubleLeftIcon from './icons/ChevronDoubleLeftIcon';
import Tooltip from './Tooltip';
import HistoryIcon from './icons/HistoryIcon';
import KeyIcon from './icons/KeyIcon';

interface SidebarProps {
  activeApi: ApiType;
  setActiveApi: (api: ApiType) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  onToggleHistory: () => void;
  onToggleApiKeyModal: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeApi, setActiveApi, isCollapsed, setIsCollapsed, onToggleHistory, onToggleApiKeyModal }) => {
  return (
    <aside
      className={`relative flex flex-col bg-gray-800 border-r border-gray-700 transition-all duration-300 ease-in-out ${
        isCollapsed ? 'w-20' : 'w-64'
      }`}
    >
      <nav className="flex-grow pt-6">
        <ul>
          {/* Fix: Cast Object.values to ApiType[] to ensure correct type for 'api' variable */}
          {(Object.values(ApiType) as ApiType[]).map((api) => {
            const details = ApiDetails[api];
            const isActive = activeApi === api;
            return (
              <li key={api} className="px-4 mb-2">
                <Tooltip text={details.label} show={isCollapsed}>
                  <button
                    onClick={() => setActiveApi(api)}
                    className={`w-full flex items-center p-3 rounded-lg transition-colors duration-200 ${
                      isCollapsed ? 'justify-center' : ''
                    } ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-lg'
                        : 'text-gray-400 hover:bg-gray-700 hover:text-white'
                    }`}
                  >
                    <details.Icon className="h-6 w-6 shrink-0" />
                    {!isCollapsed && (
                      <span className="ml-4 font-semibold whitespace-nowrap">{details.label}</span>
                    )}
                  </button>
                </Tooltip>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="p-4 border-t border-gray-700">
         <div className="px-4 mb-2">
          <Tooltip text="History" show={isCollapsed}>
            <button
              onClick={onToggleHistory}
              className={`w-full flex items-center p-3 rounded-lg transition-colors duration-200 text-gray-400 hover:bg-gray-700 hover:text-white ${
                isCollapsed ? 'justify-center' : ''
              }`}
            >
              <HistoryIcon className="h-6 w-6 shrink-0" />
              {!isCollapsed && (
                <span className="ml-4 font-semibold whitespace-nowrap">History</span>
              )}
            </button>
          </Tooltip>
        </div>
        <div className="px-4 mb-2">
            <Tooltip text="Manage API Key" show={isCollapsed}>
                <button
                onClick={onToggleApiKeyModal}
                className={`w-full flex items-center p-3 rounded-lg transition-colors duration-200 text-gray-400 hover:bg-gray-700 hover:text-white ${isCollapsed ? 'justify-center' : ''
                    }`}
                >
                <KeyIcon className="h-6 w-6 shrink-0" />
                {!isCollapsed && (
                    <span className="ml-4 font-semibold whitespace-nowrap">API Key</span>
                )}
                </button>
            </Tooltip>
         </div>
        <Tooltip text={isCollapsed ? 'Expand' : 'Collapse'}>
            <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className={`w-full flex items-center p-3 rounded-lg text-gray-400 hover:bg-gray-700 hover:text-white transition-colors duration-200 ${
                isCollapsed ? 'justify-center' : ''
            }`}
            >
            <ChevronDoubleLeftIcon
                className={`h-6 w-6 shrink-0 transition-transform duration-300 ${
                isCollapsed ? 'rotate-180' : ''
                }`}
            />
            {!isCollapsed && (
                <span className="ml-4 font-semibold whitespace-nowrap">Collapse</span>
            )}
            </button>
        </Tooltip>
      </div>
    </aside>
  );
};

export default Sidebar;