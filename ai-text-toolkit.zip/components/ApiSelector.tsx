import React from 'react';
import { ApiType } from '../types';
import { ApiDetails } from '../constants';

interface ApiSelectorProps {
  activeApi: ApiType;
  setActiveApi: (api: ApiType) => void;
  setOutputText: (text: string) => void;
}

const ApiSelector: React.FC<ApiSelectorProps> = ({ activeApi, setActiveApi, setOutputText }) => {
  const handleApiChange = (api: ApiType) => {
    setActiveApi(api);
    setOutputText(''); // Clear output when changing API
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
      {/* Fix: Cast Object.values to ApiType[] to ensure correct type for 'api' variable */}
      {(Object.values(ApiType) as ApiType[]).map((api) => {
        const details = ApiDetails[api];
        const isActive = activeApi === api;
        return (
          <button
            key={api}
            onClick={() => handleApiChange(api)}
            className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all duration-300 transform hover:-translate-y-1 ${
              isActive
                ? 'bg-indigo-600 border-indigo-500 shadow-lg shadow-indigo-600/30'
                : 'bg-gray-800 border-gray-700 hover:bg-gray-700 hover:border-gray-600'
            }`}
          >
            <details.Icon className={`h-8 w-8 mb-2 ${isActive ? 'text-white' : 'text-indigo-400'}`} />
            <span className={`font-semibold ${isActive ? 'text-white' : 'text-gray-300'}`}>{details.label}</span>
          </button>
        );
      })}
    </div>
  );
};

export default ApiSelector;
