import React, { useMemo } from 'react';
import { VisualizationData } from '../types';

interface VisualizationDisplayProps {
  data: VisualizationData;
}

const VisualizationDisplay: React.FC<VisualizationDisplayProps> = ({ data }) => {
  const { nodes, links } = data;

  const nodePositions = useMemo(() => {
    const positions = new Map<string, { x: number; y: number }>();
    const count = nodes.length;
    if (count === 0) return positions;

    const width = 500;
    const height = 400;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 2 * 0.8;

    nodes.forEach((node, i) => {
      const angle = (i / count) * 2 * Math.PI;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      positions.set(node.id, { x, y });
    });

    return positions;
  }, [nodes]);

  if (nodes.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        <p>No concepts found to visualize.</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex items-center justify-center p-4">
        <svg viewBox="0 0 500 400" className="w-full h-full">
            <defs>
                <marker
                    id="arrowhead"
                    viewBox="0 0 10 10"
                    refX="9"
                    refY="5"
                    markerWidth="6"
                    markerHeight="6"
                    orient="auto-start-reverse"
                >
                    <path d="M 0 0 L 10 5 L 0 10 z" fill="#6b7280" />
                </marker>
            </defs>

            {/* Links and Link Labels */}
            {links.map((link, i) => {
                const sourcePos = nodePositions.get(link.source);
                const targetPos = nodePositions.get(link.target);

                if (!sourcePos || !targetPos) return null;

                const midX = (sourcePos.x + targetPos.x) / 2;
                const midY = (sourcePos.y + targetPos.y) / 2;

                return (
                    <g key={`${link.source}-${link.target}-${i}`}>
                        <line
                            x1={sourcePos.x}
                            y1={sourcePos.y}
                            x2={targetPos.x}
                            y2={targetPos.y}
                            stroke="#6b7280" // gray-500
                            strokeWidth="1.5"
                            markerEnd="url(#arrowhead)"
                        />
                        <text
                            x={midX}
                            y={midY - 5}
                            fill="#d1d5db" // gray-300
                            fontSize="10"
                            textAnchor="middle"
                            className="font-sans"
                            style={{ paintOrder: 'stroke', stroke: '#1f2937', strokeWidth: '3px', strokeLinejoin: 'round' }}
                        >
                            {link.label}
                        </text>
                    </g>
                );
            })}

            {/* Nodes and Node Labels */}
            {nodes.map((node) => {
                const pos = nodePositions.get(node.id);
                if (!pos) return null;

                return (
                    <g key={node.id} className="cursor-pointer group">
                        <circle cx={pos.x} cy={pos.y} r="8" fill="#4f46e5" className="group-hover:fill-purple-500 transition-colors" />
                        <text
                            x={pos.x}
                            y={pos.y - 15}
                            fill="#e5e7eb" // gray-200
                            fontSize="12"
                            fontWeight="bold"
                            textAnchor="middle"
                            className="font-sans"
                            style={{ paintOrder: 'stroke', stroke: '#1f2937', strokeWidth: '3px', strokeLinejoin: 'round' }}
                        >
                            {node.label}
                        </text>
                    </g>
                );
            })}
        </svg>
    </div>
  );
};

export default VisualizationDisplay;
