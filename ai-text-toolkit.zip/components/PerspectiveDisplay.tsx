import React from 'react';
import { PerspectiveOutput } from '../types';
import BeginnerIcon from './icons/BeginnerIcon';
import ExpertIcon from './icons/ExpertIcon';
import AlienIcon from './icons/AlienIcon';
import FutureSelfIcon from './icons/FutureSelfIcon';

interface PerspectiveDisplayProps {
  data: PerspectiveOutput;
}

const perspectiveDetails = {
  beginner: { title: "The Beginner's Mind", Icon: BeginnerIcon, color: 'text-green-400' },
  expert: { title: "The Expert's Eye", Icon: ExpertIcon, color: 'text-blue-400' },
  alien: { title: "The Alien's View", Icon: AlienIcon, color: 'text-purple-400' },
  futureSelf: { title: "The Future Self's Wisdom", Icon: FutureSelfIcon, color: 'text-amber-400' },
};

const PerspectiveCard: React.FC<{ name: keyof PerspectiveOutput; text: string; }> = ({ name, text }) => {
    const details = perspectiveDetails[name];
    
    return (
        <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700 transition-shadow hover:shadow-lg">
            <div className="flex items-center gap-3 mb-3">
                <details.Icon className={`h-6 w-6 shrink-0 ${details.color}`} />
                <h3 className={`text-lg font-bold ${details.color}`}>{details.title}</h3>
            </div>
            <p className="text-sm text-gray-300 whitespace-pre-wrap font-sans">{text}</p>
        </div>
    );
}

const PerspectiveDisplay: React.FC<PerspectiveDisplayProps> = ({ data }) => {
  return (
    <div className="p-2 bg-gray-900/50 rounded-lg h-full overflow-y-auto animate-fade-in">
        <div className="space-y-4">
            {(Object.keys(data) as Array<keyof PerspectiveOutput>).map((key) => (
                <PerspectiveCard key={key} name={key} text={data[key]} />
            ))}
        </div>
    </div>
  );
};

export default PerspectiveDisplay;