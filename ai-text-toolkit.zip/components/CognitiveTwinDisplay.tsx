import React from 'react';
import { CognitiveProfile } from '../types';
import BrainCircuitIcon from './icons/BrainCircuitIcon';

interface CognitiveTwinDisplayProps {
  data: CognitiveProfile;
}

const TraitCard: React.FC<{ name: string; description: string }> = ({ name, description }) => (
    <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
        <h4 className="text-md font-bold text-indigo-400 mb-2">{name}</h4>
        <p className="text-sm text-gray-300">{description}</p>
    </div>
);


const CognitiveTwinDisplay: React.FC<CognitiveTwinDisplayProps> = ({ data }) => {
  return (
    <div className="p-4 bg-gray-900/50 rounded-lg h-full overflow-y-auto animate-fade-in">
      <header className="pb-4 mb-4 border-b-2 border-indigo-500">
        <div className="flex items-center gap-3">
            <BrainCircuitIcon className="h-8 w-8 text-indigo-400" />
            <div>
                <p className="text-sm font-semibold text-gray-400 mb-1">Cognitive Profile</p>
                <h2 className="text-2xl font-bold text-gray-100">{data.profileTitle}</h2>
            </div>
        </div>
      </header>
      <main>
        <div className="mb-6">
            <h3 className="text-sm font-bold uppercase tracking-wider text-gray-500 mb-2">Summary</h3>
            <p className="text-gray-300 italic">{data.summary}</p>
        </div>

        <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-gray-500 mb-3">Identified Traits</h3>
            <div className="space-y-3">
                {data.traits.map((trait) => (
                    <TraitCard key={trait.name} name={trait.name} description={trait.description} />
                ))}
            </div>
        </div>
      </main>
    </div>
  );
};

export default CognitiveTwinDisplay;