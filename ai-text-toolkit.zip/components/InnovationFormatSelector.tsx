import React from 'react';
import { InnovationFormat } from '../types';
import DocumentTextIcon from './icons/DocumentTextIcon';
import LightBulbIcon from './icons/LightBulbIcon';
import BeakerIcon from './icons/BeakerIcon';

interface InnovationFormatSelectorProps {
  selectedFormat: InnovationFormat;
  setFormat: (format: InnovationFormat) => void;
}

const formats: { name: InnovationFormat; Icon: React.FC<React.SVGProps<SVGSVGElement>> }[] = [
  { name: 'Research Paper', Icon: DocumentTextIcon },
  { name: 'Invention', Icon: LightBulbIcon },
  { name: 'Theory', Icon: BeakerIcon },
];

const InnovationFormatSelector: React.FC<InnovationFormatSelectorProps> = ({ selectedFormat, setFormat }) => {
  return (
    <div className="mb-4 p-1 bg-gray-800 border border-gray-700 rounded-lg flex items-center gap-1 animate-fade-in">
        <label className="pl-3 pr-2 text-gray-400 font-medium text-sm whitespace-nowrap">Output Format:</label>
        <div className="flex items-center gap-1">
            {formats.map(({ name, Icon }) => (
            <button
                key={name}
                onClick={() => setFormat(name)}
                className={`flex items-center gap-2 px-3 py-1.5 text-sm font-semibold rounded-md transition-colors duration-200 ${
                selectedFormat === name
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
            >
                <Icon className="h-4 w-4" />
                {name}
            </button>
            ))}
        </div>
    </div>
  );
};

export default InnovationFormatSelector;