import React from 'react';
import MicrophoneIcon from './icons/MicrophoneIcon';
import Tooltip from './Tooltip';

interface VoiceInputControlProps {
  isListening: boolean;
  isAvailable: boolean;
  onToggle: () => void;
}

const VoiceInputControl: React.FC<VoiceInputControlProps> = ({ isListening, isAvailable, onToggle }) => {
  if (!isAvailable) {
    return null;
  }

  return (
    <div className="absolute bottom-4 right-4 z-10">
      <Tooltip text={isListening ? 'Stop listening' : 'Start voice input'}>
        <button
          onClick={onToggle}
          className={`relative flex items-center justify-center h-10 w-10 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 ${
            isListening 
              ? 'bg-red-600 hover:bg-red-700 text-white' 
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
          }`}
          aria-label={isListening ? 'Stop listening' : 'Start listening'}
        >
          {isListening && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>}
          <MicrophoneIcon className="h-6 w-6 relative" />
        </button>
      </Tooltip>
    </div>
  );
};

export default VoiceInputControl;