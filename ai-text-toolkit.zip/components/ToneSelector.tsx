import React from 'react';
import { Tone } from '../types';

interface ToneSelectorProps {
  selectedTone: Tone;
  setTone: (tone: Tone) => void;
  tones: Tone[];
}

const ToneSelector: React.FC<ToneSelectorProps> = ({ selectedTone, setTone, tones }) => {
  return (
    <div className="flex items-center bg-gray-800 border border-gray-700 rounded-lg p-1">
      <label className="pl-3 pr-2 text-gray-400 font-medium text-sm">Tone:</label>
      <div className="flex items-center gap-1">
        {tones.map((tone) => (
          <button
            key={tone}
            onClick={() => setTone(tone)}
            className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors duration-200 ${
              selectedTone === tone
                ? 'bg-indigo-600 text-white'
                : 'text-gray-300 hover:bg-gray-700'
            }`}
          >
            {tone}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ToneSelector;
