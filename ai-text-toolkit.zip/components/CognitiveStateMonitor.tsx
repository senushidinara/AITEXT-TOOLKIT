import React from 'react';
import { CognitiveStateAnalysis } from '../types';
import CognitiveStateIcon from './icons/CognitiveStateIcon';

interface CognitiveStateMonitorProps {
  state: CognitiveStateAnalysis | null;
  isDetecting: boolean;
  onAction: (action: CognitiveStateAnalysis['unarticulatedNeed']['action']) => void;
}

const CognitiveStateMonitor: React.FC<CognitiveStateMonitorProps> = ({ state, isDetecting, onAction }) => {
  if (!isDetecting && !state) {
    return null;
  }

  const stateColors = {
    Curious: 'text-blue-400',
    Confident: 'text-green-400',
    Confused: 'text-yellow-400',
    Neutral: 'text-gray-400',
  };

  return (
    <div className="animate-fade-in">
        <div className="bg-gray-900/80 backdrop-blur-md border border-gray-700 rounded-lg p-2.5 shadow-lg">
             <div className="flex items-center gap-3">
                {isDetecting && !state && (
                    <>
                        <svg className="animate-spin h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span className="text-sm text-gray-400 italic">Detecting state...</span>
                    </>
                )}
                {state && (
                    <>
                        <CognitiveStateIcon state={state.cognitiveState} className={`h-5 w-5 shrink-0 ${stateColors[state.cognitiveState]}`} />
                        <span className={`text-sm font-semibold ${stateColors[state.cognitiveState]}`}>{state.cognitiveState}</span>
                        <div className="h-4 w-px bg-gray-600"></div>
                        <button
                            onClick={() => onAction(state.unarticulatedNeed.action)}
                            className="px-2.5 py-1 bg-gray-700 text-gray-300 rounded-md text-xs font-medium hover:bg-indigo-600 hover:text-white transition-colors whitespace-nowrap"
                        >
                            {state.unarticulatedNeed.label}
                        </button>
                    </>
                )}
             </div>
        </div>
    </div>
  );
};

export default CognitiveStateMonitor;
