import React from 'react';
import { SuggestedAction } from '../types';
import MagicWandIcon from './icons/MagicWandIcon';

interface ProactiveAssistantProps {
  actions: SuggestedAction[];
  onActionClick: (action: SuggestedAction) => void;
}

const ProactiveAssistant: React.FC<ProactiveAssistantProps> = ({ actions, onActionClick }) => {
  if (actions.length === 0) {
    return null;
  }

  return (
    <div className="mt-6 bg-gray-800 rounded-xl border border-gray-700 shadow-lg p-4 animate-fade-in">
      <h3 className="flex items-center text-lg font-semibold text-gray-300 mb-3">
        <MagicWandIcon className="h-6 w-6 mr-3 text-purple-400" />
        Suggested Next Steps
      </h3>
      <div className="flex flex-wrap gap-2">
        {actions.map((action, index) => (
          <button
            key={index}
            onClick={() => onActionClick(action)}
            className="px-3 py-1.5 bg-gray-700 text-gray-300 rounded-full text-sm font-medium hover:bg-indigo-600 hover:text-white transition-all"
          >
            {action.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ProactiveAssistant;
