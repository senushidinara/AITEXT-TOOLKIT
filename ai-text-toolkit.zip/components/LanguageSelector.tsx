
import React from 'react';

interface LanguageSelectorProps {
  targetLanguage: string;
  setTargetLanguage: (language: string) => void;
  languages: string[];
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ targetLanguage, setTargetLanguage, languages }) => {
  return (
    <div className="flex items-center">
      <label htmlFor="language-select" className="mr-3 text-gray-400 font-medium whitespace-nowrap">
        Translate to:
      </label>
      <select
        id="language-select"
        value={targetLanguage}
        onChange={(e) => setTargetLanguage(e.target.value)}
        className="bg-gray-700 border border-gray-600 text-white rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
      >
        {languages.map((lang) => (
          <option key={lang} value={lang}>
            {lang}
          </option>
        ))}
      </select>
    </div>
  );
};

export default LanguageSelector;