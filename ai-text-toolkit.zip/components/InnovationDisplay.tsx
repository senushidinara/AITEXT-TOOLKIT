import React from 'react';
import { StructuredInnovationOutput } from '../types';

interface InnovationDisplayProps {
  data: StructuredInnovationOutput;
}

const InnovationDisplay: React.FC<InnovationDisplayProps> = ({ data }) => {

  const renderSection = (key: string, value: any) => {
    // Sanitize key for display
    const title = key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());
    
    let content;
    if (Array.isArray(value)) {
        content = (
            <ul className="list-disc list-inside pl-2 space-y-1">
                {value.map((item, index) => <li key={index}>{item}</li>)}
            </ul>
        )
    } else {
        content = <p className="whitespace-pre-wrap">{value}</p>;
    }

    return (
        <div key={key} className="py-4 border-b border-gray-700 last:border-b-0">
            <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-400 mb-2">{title}</h3>
            <div className="text-gray-300 font-sans">{content}</div>
        </div>
    );
  }

  // Keys to not render as standard sections
  const specialKeys = ['format', 'title'];
  const sections = Object.entries(data).filter(([key]) => !specialKeys.includes(key));

  return (
    <div className="p-4 bg-gray-900/50 rounded-lg h-full overflow-y-auto animate-fade-in">
      <header className="pb-4 mb-4 border-b-2 border-indigo-500">
        <p className="text-sm font-semibold text-gray-400 mb-1">{data.format}</p>
        <h2 className="text-2xl font-bold text-gray-100">{data.title}</h2>
      </header>
      <main>
        {sections.map(([key, value]) => renderSection(key, value))}
      </main>
    </div>
  );
};

export default InnovationDisplay;