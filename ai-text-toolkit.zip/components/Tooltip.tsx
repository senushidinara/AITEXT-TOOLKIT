import React from 'react';

interface TooltipProps {
  children: React.ReactNode;
  text: string;
  show?: boolean; // Optionally control visibility externally
}

const Tooltip: React.FC<TooltipProps> = ({ children, text, show = true }) => {
  return (
    <div className="relative group flex justify-center">
      {children}
      {show && (
        <span className="absolute left-full ml-4 px-2 py-1 bg-gray-900/80 border border-gray-600 text-white text-xs rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
          {text}
        </span>
      )}
    </div>
  );
};

export default Tooltip;
