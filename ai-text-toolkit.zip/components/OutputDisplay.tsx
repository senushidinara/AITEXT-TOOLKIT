import React, { useState, useEffect } from 'react';
import ClipboardIcon from './icons/ClipboardIcon';
import CheckIcon from './icons/CheckIcon';
import Tooltip from './Tooltip';
import { ApiType, VisualizationData, StructuredInnovationOutput, CognitiveProfile, PerspectiveOutput } from '../types';
import VisualizationDisplay from './VisualizationDisplay';
import InnovationDisplay from './InnovationDisplay';
import CognitiveTwinDisplay from './CognitiveTwinDisplay';
import PerspectiveDisplay from './PerspectiveDisplay';

interface OutputDisplayProps {
  outputText: string;
  isLoading: boolean;
  error: string | null;
  activeApi: ApiType;
  visualizationData: VisualizationData | null;
  structuredInnovation: StructuredInnovationOutput | null;
  cognitiveProfile: CognitiveProfile | null;
  perspectiveOutput: PerspectiveOutput | null;
}

const OutputDisplay: React.FC<OutputDisplayProps> = ({ outputText, isLoading, error, activeApi, visualizationData, structuredInnovation, cognitiveProfile, perspectiveOutput }) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [copied]);
  
  const handleCopy = () => {
    if (outputText) {
      navigator.clipboard.writeText(outputText);
      setCopied(true);
    }
  };

  const hasSpecialDisplay = (activeApi === ApiType.Visualize && visualizationData) || 
                            (activeApi === ApiType.Innovate && structuredInnovation) ||
                            (activeApi === ApiType.Twin && cognitiveProfile) ||
                            (activeApi === ApiType.Perspective && perspectiveOutput);

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-full">
          <div className="flex flex-col items-center">
             <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-indigo-500"></div>
             <p className="mt-4 text-gray-400">AI is thinking...</p>
          </div>
        </div>
      );
    }
    if (error) {
      return (
        <div className="flex items-center justify-center h-full p-4">
            <div className="text-center bg-red-900/50 border border-red-700 p-6 rounded-lg">
                <p className="font-bold text-red-400">An Error Occurred</p>
                <p className="text-red-300 mt-2">{error}</p>
            </div>
        </div>
      );
    }

    if (activeApi === ApiType.Visualize && visualizationData) {
      return <VisualizationDisplay data={visualizationData} />;
    }
    
    if (activeApi === ApiType.Innovate && structuredInnovation) {
      return <InnovationDisplay data={structuredInnovation} />;
    }
    
    if (activeApi === ApiType.Twin && cognitiveProfile) {
      return <CognitiveTwinDisplay data={cognitiveProfile} />;
    }

    if (activeApi === ApiType.Perspective && perspectiveOutput) {
      return <PerspectiveDisplay data={perspectiveOutput} />;
    }

    if (!outputText && ![ApiType.Twin, ApiType.Perspective].includes(activeApi)) {
      return (
        <div className="flex items-center justify-center h-full text-center text-gray-500">
          <p>Your generated text will appear here.</p>
        </div>
      );
    }
    
    if (activeApi === ApiType.Twin || activeApi === ApiType.Perspective) {
       return (
        <div className="flex items-center justify-center h-full text-center text-gray-500">
          <p>Your generated output will appear here.</p>
        </div>
      );
    }

    return (
        <pre className="whitespace-pre-wrap break-words p-4 font-sans text-gray-300">{outputText}</pre>
    );
  };

  return (
    <div className="relative flex flex-col bg-gray-800 rounded-xl border border-gray-700 shadow-lg h-full">
        <div className="p-4 border-b border-gray-700 flex justify-between items-center">
             <h2 className="text-lg font-semibold text-gray-300">Output</h2>
            {!hasSpecialDisplay && (
              <Tooltip text="Copy to clipboard">
                <button
                    onClick={handleCopy}
                    disabled={!outputText || copied}
                    className="flex items-center px-3 py-1 bg-gray-700 text-gray-300 rounded-md hover:bg-gray-600 disabled:opacity-50 transition-all"
                >
                    {copied ? <CheckIcon className="h-5 w-5 mr-2 text-green-400" /> : <ClipboardIcon className="h-5 w-5 mr-2" />}
                    {copied ? 'Copied!' : 'Copy'}
                </button>
              </Tooltip>
            )}
        </div>
      <div className="flex-grow overflow-auto p-4">
        {renderContent()}
      </div>
    </div>
  );
};

export default OutputDisplay;