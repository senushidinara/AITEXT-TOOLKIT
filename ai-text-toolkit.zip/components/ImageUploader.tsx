import React, { useRef, useState, useCallback } from 'react';
import UploadIcon from './icons/UploadIcon';
import XCircleIcon from './icons/XCircleIcon';
import Tooltip from './Tooltip';

interface ImageUploaderProps {
  onImageSelect: (image: { data: string; mimeType: string }) => void;
  onImageRemove: () => void;
  selectedImage: { data: string; mimeType: string } | null;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelect, onImageRemove, selectedImage }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  const processFile = useCallback((file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        onImageSelect({ data: base64String, mimeType: file.type });
      };
      reader.readAsDataURL(file);
    }
  }, [onImageSelect]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };
  
  const handleDragEnter = (e: React.DragEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLButtonElement>) => {
    e.preventDefault(); // This is necessary to allow dropping
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };


  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="p-4 border-t border-gray-700">
      {selectedImage ? (
        <div className="relative group">
          <img
            src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`}
            alt="Uploaded preview"
            className="rounded-lg max-h-48 w-full object-contain bg-gray-900/50"
          />
          <Tooltip text="Remove image">
            <button
              onClick={onImageRemove}
              className="absolute top-2 right-2 bg-black/60 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100"
              aria-label="Remove image"
            >
              <XCircleIcon className="h-6 w-6" />
            </button>
          </Tooltip>
        </div>
      ) : (
        <button
          onClick={triggerFileInput}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className={`w-full flex flex-col items-center justify-center p-6 border-2 border-dashed  rounded-lg text-gray-400 transition-colors duration-300 ${
            isDraggingOver 
              ? 'bg-indigo-900/50 border-indigo-500' 
              : 'border-gray-600 hover:bg-gray-700/50 hover:border-gray-500'
          }`}
        >
          <UploadIcon className="h-8 w-8 mb-2" />
          <span className="font-semibold">{isDraggingOver ? 'Drop image here' : 'Upload an Image'}</span>
          <p className="text-xs text-gray-500 mt-1">or drag and drop</p>
        </button>
      )}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/*"
      />
    </div>
  );
};

export default ImageUploader;