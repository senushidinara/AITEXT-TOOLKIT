import React, { useState, useCallback, useEffect, useRef } from 'react';
import { ApiType, SuggestedAction, Tone, HistoryItem, PreCognitiveAction, VisualizationData, InnovationFormat, StructuredInnovationOutput, FutureInsightAction, CognitiveProfile, CognitiveStateAnalysis, PerspectiveOutput } from './types';
import { ApiDetails, LANGUAGES, TONES } from './constants';
import { summarizeText, translateText, writeText, rewriteText, proofreadText, askAnything, innovateText, visualizeText, generateSuggestedActions, getPreCognitiveSuggestions, generateFutureInsight, generateCognitiveProfile, detectCognitiveState, generatePerspectives } from './services/geminiService';

import Sidebar from './components/Sidebar';
import LanguageSelector from './components/LanguageSelector';
import OutputDisplay from './components/OutputDisplay';
import ImageUploader from './components/ImageUploader';
import ProactiveAssistant from './components/ProactiveAssistant';
import ToneSelector from './components/ToneSelector';
import HistoryPanel from './components/HistoryPanel';
import VoiceInputControl from './components/VoiceInputControl';
import PreCognitiveAssistant from './components/PreCognitiveAssistant';
import JourneyDisplay from './components/JourneyDisplay';
import InnovationFormatSelector from './components/InnovationFormatSelector';
import FutureInsight from './components/FutureInsight';
import BrainCircuitIcon from './components/icons/BrainCircuitIcon';
import CognitiveStateMonitor from './components/CognitiveStateMonitor';
import ExamplePrompts from './components/ExamplePrompts';
import ApiKeyModal from './components/ApiKeyModal';


// Fix: Add type definitions for the non-standard SpeechRecognition API to resolve compilation errors.
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: any) => void) | null;
  onresult: ((event: any) => void) | null;
}

// Extend window type for SpeechRecognition
declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

const App: React.FC = () => {
  const [activeApi, setActiveApi] = useState<ApiType>(ApiType.Summarize);
  const [inputText, setInputText] = useState<string>('');
  const [outputText, setOutputText] = useState<string>('');
  const [targetLanguage, setTargetLanguage] = useState<string>('Spanish');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [image, setImage] = useState<{ data: string; mimeType: string } | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [suggestedActions, setSuggestedActions] = useState<SuggestedAction[]>([]);
  const [tone, setTone] = useState<Tone>('Default');
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isHistoryPanelOpen, setIsHistoryPanelOpen] = useState(false);
  const [historyParentId, setHistoryParentId] = useState<string | null>(null);
  const [lastGenerationId, setLastGenerationId] = useState<string | null>(null);
  
  // API Key State
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);


  // Voice Input State
  const [isListening, setIsListening] = useState<boolean>(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const textBeforeListeningRef = useRef<string>('');
  
  // Assistants State
  const [preCognitiveActions, setPreCognitiveActions] = useState<PreCognitiveAction[]>([]);
  const [futureInsight, setFutureInsight] = useState<FutureInsightAction | null>(null);
  const [cognitiveStateAnalysis, setCognitiveStateAnalysis] = useState<CognitiveStateAnalysis | null>(null);
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [isForecasting, setIsForecasting] = useState<boolean>(false);
  const [isDetectingState, setIsDetectingState] = useState<boolean>(false);
  const debounceTimeoutRef = useRef<number | null>(null);

  // Specialized Output State
  const [visualizationData, setVisualizationData] = useState<VisualizationData | null>(null);
  const [structuredInnovation, setStructuredInnovation] = useState<StructuredInnovationOutput | null>(null);
  const [innovationFormat, setInnovationFormat] = useState<InnovationFormat>('Research Paper');
  const [cognitiveProfile, setCognitiveProfile] = useState<CognitiveProfile | null>(null);
  const [perspectiveOutput, setPerspectiveOutput] = useState<PerspectiveOutput | null>(null);


  const currentApiDetails = ApiDetails[activeApi];
  
  // Effect for API Key Management
  useEffect(() => {
    const savedKey = localStorage.getItem('user-api-key');
    if (savedKey) {
      setApiKey(savedKey);
    } else {
      setIsApiKeyModalOpen(true);
    }
  }, []);


  useEffect(() => {
    if (activeApi !== ApiType.Prompt && image) {
      setImage(null);
    }
  }, [activeApi, image]);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("Speech recognition not supported in this browser.");
      return;
    }

    const recognition: SpeechRecognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => {
        setIsListening(false);
        setInputText(textBeforeListeningRef.current);
    };
    recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
    };

    recognition.onresult = (event) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                const finalTranscript = event.results[i][0].transcript.trim() + '. ';
                textBeforeListeningRef.current += finalTranscript;
            } else {
                interimTranscript += event.results[i][0].transcript;
            }
        }
        setInputText(textBeforeListeningRef.current + interimTranscript);
    };

    recognitionRef.current = recognition;

    return () => {
        recognition.stop();
    };
  }, []);
  
  // Effect for all real-time Assistants
  useEffect(() => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }
    
    setPreCognitiveActions([]);
    setFutureInsight(null);
    setCognitiveStateAnalysis(null);

    const canTriggerAssistants = inputText.trim().length > 30 && ![ApiType.Journey, ApiType.Twin].includes(activeApi) && apiKey;

    if (canTriggerAssistants) {
      setIsThinking(true);
      setIsForecasting(true);
      setIsDetectingState(true);

      debounceTimeoutRef.current = window.setTimeout(async () => {
        // Run all assistants in parallel
        const [suggestions, insight, cognitiveState] = await Promise.all([
          getPreCognitiveSuggestions(apiKey, inputText, activeApi),
          generateFutureInsight(apiKey, inputText, activeApi),
          detectCognitiveState(apiKey, inputText),
        ]);
        setPreCognitiveActions(suggestions);
        setFutureInsight(insight);
        setCognitiveStateAnalysis(cognitiveState);
        setIsThinking(false);
        setIsForecasting(false);
        setIsDetectingState(false);
      }, 1500);
    } else {
      setIsThinking(false);
      setIsForecasting(false);
      setIsDetectingState(false);
    }

    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, [inputText, activeApi, apiKey]);

  // Effect for Cognitive Twin
  useEffect(() => {
    const generateAndSetProfile = async () => {
      if (!apiKey) return;
      setIsLoading(true);
      setError(null);
      setCognitiveProfile(null);
      try {
        const result = await generateCognitiveProfile(apiKey, history);
        const parsedProfile = JSON.parse(result) as CognitiveProfile;
        setCognitiveProfile(parsedProfile);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to generate cognitive profile.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    if (activeApi === ApiType.Twin) {
      generateAndSetProfile();
    }
  }, [activeApi, history, apiKey]);

  const handleToggleListening = () => {
      const recognition = recognitionRef.current;
      if (!recognition) return;

      if (isListening) {
          recognition.stop();
      } else {
          textBeforeListeningRef.current = inputText ? inputText.trim() + ' ' : '';
          recognition.start();
      }
  };

  const resetOutputs = () => {
    setOutputText('');
    setError(null);
    setSuggestedActions([]);
    setHistoryParentId(null);
    setVisualizationData(null);
    setStructuredInnovation(null);
    setCognitiveProfile(null);
    setPerspectiveOutput(null);
  }
  
  const resetAssistants = () => {
    setPreCognitiveActions([]);
    setIsThinking(false);
    setFutureInsight(null);
    setIsForecasting(false);
    setCognitiveStateAnalysis(null);
    setIsDetectingState(false);
  }

  const handleApiChange = (api: ApiType) => {
    setActiveApi(api);
    setInputText('');
    setImage(null);
    setTone('Default');
    resetOutputs();
    resetAssistants();
  };
  
  const fetchAndSetSuggestedActions = async (currentApi: ApiType, input: string, resultText: string) => {
    if (!apiKey) return;
    if (!resultText.trim()) {
      setSuggestedActions([]);
      return;
    }
    const actions = await generateSuggestedActions(apiKey, currentApi, input, resultText);
    setSuggestedActions(actions);
  };

  const handleSaveApiKey = (key: string) => {
    const trimmedKey = key.trim();
    if (trimmedKey) {
        setApiKey(trimmedKey);
        localStorage.setItem('user-api-key', trimmedKey);
        setIsApiKeyModalOpen(false);
        setError(null); // Clear any previous API key errors
    }
  };
  
  const handleToggleApiKeyModal = () => {
      // Allow opening, but only allow closing if a key is already set.
      if (isApiKeyModalOpen && !apiKey) return; 
      setIsApiKeyModalOpen(prev => !prev);
  }


  const handleSuggestedAction = (action: SuggestedAction) => {
    setInputText(outputText);
    setActiveApi(action.api);
    setError(null);
    setHistoryParentId(lastGenerationId); // Set parent for the next generation
    resetOutputs();
    resetAssistants();
  };
  
  const handlePreCognitiveAction = (action: PreCognitiveAction) => {
    if (action.newInput) {
        setInputText(action.newInput);
    }
    if (action.api) {
        setActiveApi(action.api);
    }
    resetAssistants();
  };
  
  const handleFutureInsightAction = (action: FutureInsightAction['solutionAction']) => {
    if (action.newInput) {
      setInputText(action.newInput);
    }
    if (action.api) {
      setActiveApi(action.api);
    }
    resetAssistants();
  };
  
  const handleCognitiveStateAction = (action: CognitiveStateAnalysis['unarticulatedNeed']['action']) => {
    setInputText(action.newInput);
    resetAssistants();
  };

  const handleExampleClick = (prompt: string) => {
    setInputText(prompt);
  };


  const handleGenerate = useCallback(async () => {
    if (!apiKey) {
      setError("An API Key is required. Please set one to continue.");
      setIsApiKeyModalOpen(true);
      return;
    }

    if (activeApi === ApiType.Twin) {
      // Re-trigger profile generation
       const generateAndSetProfile = async () => {
        setIsLoading(true);
        setError(null);
        setCognitiveProfile(null);
        try {
          const result = await generateCognitiveProfile(apiKey, history);
          const parsedProfile = JSON.parse(result) as CognitiveProfile;
          setCognitiveProfile(parsedProfile);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to generate cognitive profile.');
          console.error(err);
        } finally {
          setIsLoading(false);
        }
      };
      generateAndSetProfile();
      return;
    }
    
    if (!inputText.trim() && (activeApi !== ApiType.Prompt || !image)) {
      setError('Input cannot be empty.');
      return;
    }

    setIsLoading(true);
    resetOutputs();
    resetAssistants();

    try {
      let result: string;
      switch (activeApi) {
        case ApiType.Summarize:
          result = await summarizeText(apiKey, inputText);
          setOutputText(result);
          break;
        case ApiType.Translate:
          result = await translateText(apiKey, inputText, targetLanguage);
          setOutputText(result);
          break;
        case ApiType.Write:
          result = await writeText(apiKey, inputText, tone);
          setOutputText(result);
          break;
        case ApiType.Rewrite:
          result = await rewriteText(apiKey, inputText, tone);
          setOutputText(result);
          break;
        case ApiType.Proofread:
          result = await proofreadText(apiKey, inputText);
          setOutputText(result);
          break;
        case ApiType.Prompt:
          result = await askAnything(apiKey, inputText, image);
          setOutputText(result);
          break;
        case ApiType.Innovate:
          result = await innovateText(apiKey, inputText, innovationFormat);
           try {
            const parsedData = JSON.parse(result) as StructuredInnovationOutput;
            if (parsedData.format && parsedData.title) {
                setStructuredInnovation(parsedData);
            } else {
                throw new Error("Invalid innovation data structure received from AI.");
            }
          } catch (parseError) {
            console.error("Failed to parse innovation data:", parseError);
            throw new Error("The AI returned an invalid data structure for this format.");
          }
          break;
        case ApiType.Visualize:
          result = await visualizeText(apiKey, inputText);
          try {
            const parsedData = JSON.parse(result) as VisualizationData;
            if (parsedData.nodes && parsedData.links) {
              setVisualizationData(parsedData);
            } else {
              throw new Error("Invalid visualization data structure received from AI.");
            }
          } catch (parseError) {
            console.error("Failed to parse visualization data:", parseError);
            throw new Error("The AI returned an invalid data structure for visualization.");
          }
          break;
         case ApiType.Perspective:
          result = await generatePerspectives(apiKey, inputText);
           try {
            const parsedData = JSON.parse(result) as PerspectiveOutput;
            if (parsedData.beginner && parsedData.expert && parsedData.alien && parsedData.futureSelf) {
                setPerspectiveOutput(parsedData);
            } else {
                throw new Error("Invalid perspective data structure received from AI.");
            }
          } catch (parseError) {
            console.error("Failed to parse perspective data:", parseError);
            throw new Error("The AI returned an invalid data structure for perspectives.");
          }
          break;
        default:
          throw new Error('Invalid API type');
      }
      
      // For history, always use the raw string result
      setOutputText(result); 
      
      const newItemId = new Date().toISOString() + Math.random();
      setLastGenerationId(newItemId); // Set the ID for potential children
      
      const historyItem: HistoryItem = {
        id: newItemId,
        parentId: historyParentId, // Use the parent ID from state
        api: activeApi,
        input: inputText,
        output: result,
        timestamp: new Date(),
        image: image,
        tone: activeApi === ApiType.Write || activeApi === ApiType.Rewrite ? tone : undefined,
        language: activeApi === ApiType.Translate ? targetLanguage : undefined,
        innovationFormat: activeApi === ApiType.Innovate ? innovationFormat : undefined,
      };
      setHistory(prev => [historyItem, ...prev].slice(0, 50)); // Keep last 50 items
      
      if (![ApiType.Visualize, ApiType.Innovate, ApiType.Twin, ApiType.Perspective].includes(activeApi)) {
        fetchAndSetSuggestedActions(activeApi, inputText, result);
      }

    } catch (err) {
       if (err instanceof Error && err.message.includes('API key is not valid')) {
            setError(err.message);
            setIsApiKeyModalOpen(true); // Re-open modal on invalid key
        } else {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        }
      console.error(err);
      setOutputText(''); // Clear any partial output text on error
    } finally {
      setIsLoading(false);
      setHistoryParentId(null); // Reset parent ID after generation is complete
    }
  }, [activeApi, inputText, targetLanguage, image, tone, historyParentId, innovationFormat, history, apiKey]);

  const handleRestoreHistory = (item: HistoryItem) => {
    setActiveApi(item.api);
    setInputText(item.input);
    setOutputText(item.output);
    setImage(item.image || null);
    if (item.tone) setTone(item.tone);
    if (item.language) setTargetLanguage(item.language);
    if (item.innovationFormat) setInnovationFormat(item.innovationFormat);
    
    resetOutputs();
    resetAssistants();
    
    try {
        if (item.api === ApiType.Visualize) {
            const parsedData = JSON.parse(item.output) as VisualizationData;
            if (parsedData.nodes && parsedData.links) setVisualizationData(parsedData);
        } else if (item.api === ApiType.Innovate) {
            const parsedData = JSON.parse(item.output) as StructuredInnovationOutput;
            if (parsedData.format && parsedData.title) setStructuredInnovation(parsedData);
        } else if (item.api === ApiType.Perspective) {
            const parsedData = JSON.parse(item.output) as PerspectiveOutput;
            if (parsedData.beginner) setPerspectiveOutput(parsedData);
        }
    } catch {
        // Ignore parsing errors for old/invalid history items
    }
    
    setIsHistoryPanelOpen(false);
    setSuggestedActions([]);
    setError(null);
    setHistoryParentId(null);
    setLastGenerationId(item.id);
  };

  return (
    <div className="h-screen bg-gray-900 text-gray-200 font-sans flex flex-col">
      <ApiKeyModal 
        isOpen={isApiKeyModalOpen}
        onClose={handleToggleApiKeyModal}
        onSave={handleSaveApiKey}
        hasKey={!!apiKey}
      />
      <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 p-4 shrink-0 z-20">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-500">
            AI Proactive Assistant
          </h1>
        </div>
      </header>
      <div className="flex flex-grow overflow-hidden">
        <Sidebar 
          activeApi={activeApi} 
          setActiveApi={handleApiChange}
          isCollapsed={isSidebarCollapsed}
          setIsCollapsed={setIsSidebarCollapsed}
          onToggleHistory={() => setIsHistoryPanelOpen(!isHistoryPanelOpen)}
          onToggleApiKeyModal={handleToggleApiKeyModal}
        />
         <HistoryPanel
          isOpen={isHistoryPanelOpen}
          onClose={() => setIsHistoryPanelOpen(false)}
          history={history}
          onItemClick={handleRestoreHistory}
          onClear={() => setHistory([])}
        />
        <main className="flex-1 flex flex-col overflow-y-auto">
          {activeApi === ApiType.Journey ? (
            <JourneyDisplay history={history} onNodeClick={handleRestoreHistory} />
          ) : (
            <>
              <div className="flex-grow p-4 md:p-6 lg:p-8 flex flex-col">
                  <div className="flex justify-between items-center gap-4 flex-wrap">
                      <h2 className="text-2xl font-bold text-gray-200">{currentApiDetails.label}</h2>
                       {(activeApi === ApiType.Write || activeApi === ApiType.Rewrite) && (
                         <ToneSelector selectedTone={tone} setTone={setTone} tones={TONES} />
                       )}
                       {activeApi === ApiType.Translate && (
                        <LanguageSelector
                          targetLanguage={targetLanguage}
                          setTargetLanguage={setTargetLanguage}
                          languages={LANGUAGES}
                        />
                      )}
                  </div>
                  <p className="text-gray-400 mb-6">{currentApiDetails.description}</p>
                  
                  {activeApi === ApiType.Innovate && (
                    <InnovationFormatSelector 
                        selectedFormat={innovationFormat} 
                        setFormat={setInnovationFormat} 
                    />
                  )}

                <div className="flex-grow grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
                  <div className="relative flex flex-col bg-gray-800 rounded-xl border border-gray-700 shadow-lg transition-all duration-300 focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-indigo-500">
                    <div className="p-4 border-b border-gray-700">
                      <h3 className="text-lg font-semibold text-gray-300">{currentApiDetails.inputLabel}</h3>
                    </div>
                    {activeApi === ApiType.Twin ? (
                      <div className="flex-grow p-4 text-gray-400 flex flex-col items-center justify-center text-center">
                         <BrainCircuitIcon className="h-12 w-12 text-indigo-400 mb-4" />
                         <p className="font-semibold">Your Cognitive Twin is generated automatically.</p>
                         <p className="text-sm mt-2">The AI analyzes your entire session history from the "History" panel to create a profile of your thought patterns. The more you use the tools, the more accurate it becomes.</p>
                      </div>
                    ) : (
                      <>
                        <textarea
                          value={inputText}
                          onChange={(e) => setInputText(e.target.value)}
                          placeholder={currentApiDetails.placeholder}
                          className="flex-grow bg-transparent p-4 pr-14 text-gray-300 focus:outline-none resize-none"
                          rows={activeApi === ApiType.Prompt ? 5 : 10}
                        />

                        {!inputText && currentApiDetails.examples && currentApiDetails.examples.length > 0 && (
                            <ExamplePrompts 
                                prompts={currentApiDetails.examples} 
                                onPromptClick={handleExampleClick} 
                            />
                        )}

                        <VoiceInputControl
                          isAvailable={!!recognitionRef.current}
                          isListening={isListening}
                          onToggle={handleToggleListening}
                        />
                         <div className="absolute bottom-4 left-4 z-10 flex items-end gap-2 max-w-[calc(100%-60px)]">
                            <PreCognitiveAssistant
                                actions={preCognitiveActions}
                                onActionClick={handlePreCognitiveAction}
                                isThinking={isThinking}
                            />
                            <CognitiveStateMonitor 
                                state={cognitiveStateAnalysis}
                                isDetecting={isDetectingState}
                                onAction={handleCognitiveStateAction}
                            />
                        </div>
                      </>
                    )}
                    {activeApi === ApiType.Prompt && (
                      <ImageUploader
                        onImageSelect={setImage}
                        onImageRemove={() => setImage(null)}
                        selectedImage={image}
                      />
                    )}
                  </div>

                  <div className="flex flex-col">
                    <OutputDisplay 
                        outputText={outputText} 
                        isLoading={isLoading} 
                        error={error} 
                        activeApi={activeApi}
                        visualizationData={visualizationData}
                        structuredInnovation={structuredInnovation}
                        cognitiveProfile={cognitiveProfile}
                        perspectiveOutput={perspectiveOutput}
                    />
                    {![ApiType.Visualize, ApiType.Innovate, ApiType.Journey, ApiType.Twin, ApiType.Perspective].includes(activeApi) && <ProactiveAssistant actions={suggestedActions} onActionClick={handleSuggestedAction} />}
                  </div>
                </div>
                 
                 <FutureInsight
                    insight={futureInsight}
                    isForecasting={isForecasting}
                    onActionClick={handleFutureInsightAction}
                  />

                </div>
                
                <div className="mt-auto sticky bottom-0 p-4 md:p-6 lg:p-8 bg-gray-900/80 backdrop-blur-sm z-10">
                  <div className="flex justify-center">
                   <button
                      onClick={handleGenerate}
                      disabled={isLoading || !apiKey}
                      className="w-full md:w-1/2 lg:w-1/3 flex items-center justify-center px-8 py-4 bg-indigo-600 text-white font-bold rounded-lg shadow-lg hover:bg-indigo-700 disabled:bg-indigo-900/50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100"
                    >
                      {isLoading ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Generating...
                        </>
                      ) : (
                        <>
                          <currentApiDetails.Icon className="h-6 w-6 mr-3" />
                          {!apiKey ? "Set API Key to Start" : currentApiDetails.actionText}
                        </>
                      )}
                    </button>
                  </div>
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;